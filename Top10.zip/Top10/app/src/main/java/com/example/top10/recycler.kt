package com.example.top10

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item.view.*

class recycler (private val list: ArrayList<input>): RecyclerView.Adapter<recycler.ItemHolder>() {
    class ItemHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemHolder {
        return ItemHolder(LayoutInflater.from(parent.context).inflate(R.layout.item, parent, false))
    }

    override fun onBindViewHolder(holder: ItemHolder, position: Int) {

        val input=list[position]
        holder.itemView.apply {
            textView.text =input.name

        }
    }

    override fun getItemCount()= list.size

}