package com.example.top10

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Website.URL
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL

class MainActivity : AppCompatActivity() {


    lateinit var tvfeed: TextView
    lateinit var rvFeed: RecyclerView
    lateinit var btn: Button
    private val TAG = "act1"
    var listItems = ArrayList<input>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvfeed = findViewById(R.id.tv)
        btn = findViewById(R.id.button)
        btn.setOnClickListener {


            requestApi()

            initRecyclerView()

        }

    }

    private fun requestApi() {

        CoroutineScope(Dispatchers.IO).launch {


            val rssFeed = async {

                downloadXML("http://ax.itunes.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/topfreeapplications/limit=10/xml")

            }.await()

           if (rssFeed.isEmpty()) {
               Log.e(TAG, "requestApi fun: Error downloading")
            } else {

                val parseApplications = async {

                    parser()

                }.await()

                parseApplications.parse(rssFeed)
                listItems = parseApplications.getParsedList()


                withContext(Dispatchers.Main) {


                    rvFeed.adapter = recycler(listItems)


                }
           }


        }}

        private fun initRecyclerView() {
            rvFeed = findViewById(R.id.rv)
            rvFeed.layoutManager = LinearLayoutManager(this)
            rvFeed.setHasFixedSize(true)
        }

        private fun downloadXML(urlPath: String?): String {
            val xmlResult = StringBuilder()

            try {
                val url = URL(urlPath)
                val connection: HttpURLConnection = url.openConnection() as HttpURLConnection
                val response = connection.responseCode


                val reader = BufferedReader(InputStreamReader(connection.inputStream))

                val inputBuffer = CharArray(500)
                var charsRead = 0
                while (charsRead >= 0) {
                    charsRead = reader.read(inputBuffer)
                    if (charsRead > 0) {
                        xmlResult.append(String(inputBuffer, 0, charsRead))
                    }
                }
                reader.close()


                return xmlResult.toString()

            } catch (e: Exception) {
                Log.e(TAG, "${e.message}")
            }
            return ""
        }


    }
